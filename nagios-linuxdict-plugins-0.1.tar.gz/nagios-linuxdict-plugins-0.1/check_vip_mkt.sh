#!/bin/sh
#ver:1
#define alert devel of nagios 
STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKOWN=3
above=0


ippart=$(ifconfig|grep 'inet addr'|cut -d: -f2|grep '118\.'|awk '{print $1}' |head -n 1 |awk -F'.' '{print $3}')

if [ ! -z "$ippart" ];then
    if [ "$ippart" == "224" ];then
        vip1=118.26.224.21
	    ip a|grep inet|grep $vip1  1>>/dev/null 2>/dev/null
	    if [ $? -eq 0 ]
	    then
		    echo "vip is ok!"
		    exit $STATE_OK
	    else
	    	echo "Vip $vip1 is error!"
		    exit $STATE_CRITICAL
	    fi
   fi

    
    if [ "$ippart" == "235" ];then
        vip2=118.26.235.21
	    ip a|grep inet|grep $vip2 1>>/dev/null 2>/dev/null
    	if [ $? -eq 0 ]
	    then
		    echo "Vip $vip2 is ok"
		    exit $STATE_OK
	    else
		    echo "Vip $vip2 is error!"
		    exit $STATE_CRITICAL
	    fi
    fi

else
    echo  "ip is not exsit!"
        exit $STATE_CRITICAL
fi
