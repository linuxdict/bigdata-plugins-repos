#!/bin/bash

#version:1

STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKOWN=3
above=0
number=80



LANG=C
list=`df -Pi|grep -v "Filesystem"|grep -v "tmpfs"|awk '{print $1}'`


for disk_name in $list;do
	url=`df -Pi|grep $disk_name`
	size=`echo $url|awk -F\  '{print "size:" $2}'`;
	used=`echo $url|awk -F\  '{print "used:" $3}'`;
	avail=`echo $url|awk -F\  '{print "avail:" $4}'`;
	capacity=`echo $url|awk -F\  '{print $5}'`;
#	mounted=`echo $url|awk -F\  '{print "mounted:" $6}'`;
	mounted=`echo $url|awk -F\  '{print  $6}'`;
        
        percent=`echo $capacity |sed 's/%//g'`


         if [ "$percent" -ge $number ];then
                above=$[$above+1]
         tmp="$tmp $mounted [$capacity]|"
         fi
#		echo "$mounted[$capacity]"
#		echo "$mounted $size $avail capacity:$capacity"
#                continue $STATE_WARNING
#         else
#                above=0
#         fi

done;
if [ "$above" -eq 0 ];then
         echo "the disk used of space normal"
	 exit $STATE_OK
else
         echo "$tmp"
	     exit $STATE_CRITICAL
fi
