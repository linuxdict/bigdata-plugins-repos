#!/bin/bash

jpspath='sudo /usr/local/java/jdk1.6.0_45/bin/jps'
initflag=0

function check_hadprocess() {
	result=`${jpspath} | egrep -w ${1} | awk '{print $2}'`
	if [  -z ${result} ]
	then
		initflag=1
		alters="${alters} ${1} processlist failed,please check; "
		
	else
		alters="${alters} ${1} processlist OK; "
	fi

	if [ ${initflag} -eq 0 ]
	then
		if [ ${2} -eq 10 ]
		then
			echo "${alters}"
			exit 0
		fi
	else
		if [ ${2} -eq 10 ]
		then
			echo "${alters}"
			exit 2
		fi
	fi
}
check_hadprocess 'JobHistoryServer'		1
check_hadprocess 'DFSZKFailoverController'	2
check_hadprocess 'Jps'				3
check_hadprocess 'NameNode'			4
check_hadprocess 'ResourceManager'		5
check_hadprocess 'JournalNode'			6
check_hadprocess 'QuorumPeerMain'		10
unset alters
