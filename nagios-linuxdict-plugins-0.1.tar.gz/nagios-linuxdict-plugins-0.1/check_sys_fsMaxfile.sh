#!/bin/bash
STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKOWN=3

file_nums=`cat /proc/sys/fs/file-nr|awk '{print $1}'`

if [ ${file_nums} -gt 60000 ]
then
	echo "system fs.max : too many files open : ${file_nums}"
	exit $STATE_CRITICAL
else
	echo "system fs.max : files open ok : ${file_nums}"
	exit $STATE_OK
fi
