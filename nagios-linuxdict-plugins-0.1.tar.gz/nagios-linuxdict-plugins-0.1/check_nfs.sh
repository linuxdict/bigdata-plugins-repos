#!/bin/sh
#ver:1
#define alert devel of nagios 
STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKOWN=3
above=0

count=`df -hP |grep 192.168.1.64 |grep -E 'avatar|bbs.goapk.com' |wc -l`

if [ ${count} -eq 2 ]
then
	echo "nfs is mounted!"
	exit $STATE_OK
else
	echo "nfs is not mounted!"
	exit $STATE_CRITICAL
fi

