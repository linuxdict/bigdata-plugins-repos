#!/bin/bash
#ver:1

iplist=`ifconfig|grep 'inet addr'|cut -d: -f2|grep -v '^127.0.0.1'|awk '{print $1}'`
n=`ifconfig|grep 'inet addr'|cut -d: -f2|grep -v '^127.0.0.1'|wc -l`
if [ $n -ge 2 ]
then
	count=0
	for ip in $iplist
	do
		ping -c 2 $ip >/dev/null 2>&1
		if [ $? -eq 0 ]
		then
			count=$(($count+1))
		fi
	done
	if [ $count -eq $n ]
	then
		echo "ip is ok!"
		exit 0
	fi
else
	
			echo "ip setup is error!"
			exit 2
fi
