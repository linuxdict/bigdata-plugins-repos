#!/bin/bash

if pgrep keepalived >> /dev/null
then
        echo "keepalived is ok!"
        exit 0
else
        echo "keepalived porcess is stop!"
        exit 2
fi
