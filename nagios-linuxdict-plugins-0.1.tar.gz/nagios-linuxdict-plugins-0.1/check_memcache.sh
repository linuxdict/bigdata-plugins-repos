#!/bin/sh
#ver:1
#define alert devel of nagios 
STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKOWN=3
above=0

rpm -q nc >> /dev/null
if [ $? -ne 0 ]
then
yum install nc -y
fi


ip=`ifconfig em2 |grep 'inet addr'|awk '{print $2}'|awk -F: '{print $2}'`
res=`echo 'stats'|nc $ip 11211|grep pid`


if [ ! -z "$res"  ];then
	echo "memcache process is ok!"
	exit $STATE_OK
else
	echo "memcache process is stop!"
	exit $STATE_CRITICAL
fi
