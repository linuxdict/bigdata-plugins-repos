#!/bin/sh
#ver:1
#define alert devel of nagios 
STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKOWN=3
above=0

ifconfig -a |grep inet |grep '42.62.0.210'
if [ $? -eq 0 ]
then
	echo "vip is ok!"
	exit $STATE_OK
else
	echo "vip is error!"
	exit $STATE_CRITICAL
fi
