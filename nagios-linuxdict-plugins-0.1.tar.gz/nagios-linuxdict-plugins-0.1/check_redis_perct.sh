#!/bin/bash
STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKOWN=3

host_ip=`/sbin/ip a |grep 'inet'|grep 'em2'|sed -n '1 p'|awk -F '/'  '{print $1}'|awk '{print $2}'`

redis_use=`/usr/local/bin/redis-cli -h $host_ip -p 6389 info |grep 'used_memory:'|awk -F ':' '{print $2}'`
##redis 4294967296 4GB
##redis 32212254720 30GB
##redis 17179869184 16GB
redis_max=4294967296

sorce_num=`awk 'BEGIN{printf "%.2f",'"${redis_use}"'/'"${redis_max}"'}'`

percent_num=`awk 'BEGIN{print '"${sorce_num}"'*100}'`

if [ $percent_num -gt 90 ]
then
	echo "$host_ip redis used ${percent_num}% mem"
	exit $STATE_CRITICAL
elif [ $percent_num  -le 90 -a $percent_num -gt 80 ]
then
	echo "$host_ip redis used ${percent_num}% mem"
	exit $STATE_WARNING
elif [  $percent_num -le 80  ]
then
	echo "$host_ip redis used ${percent_num}% mem, redis ok"
	exit $STATE_OK
else
	echo "$host_ip redis can't connect"
	exit $STATE_CRITICAL
fi
