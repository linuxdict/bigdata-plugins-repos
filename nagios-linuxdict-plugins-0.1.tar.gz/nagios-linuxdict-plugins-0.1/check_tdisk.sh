#!/bin/bash
STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKOWN=3

list2=`df -Ph|grep -vEi "Filesystem|tmpfs"|awk '{print $1}'`

check_disk(){
a=0
for disk_name5 in $list2
do  
    url_sys5=`df -Ph|grep $disk_name5`
    size_sys5=`echo $url_sys5|awk -F\  '{print "size:" $2}'`;
    used_sys5=`echo $url_sys5|awk -F\  '{print "used:" $3}'`;
    avail_sys5=`echo $url_sys5|awk -F\  '{print "avail:" $4}'`;
    capacity_sys5=`echo $url_sys5|awk -F\  '{print $5}'`;
    mounted_sys5=`echo $url_sys5|awk -F\  '{print "mounted:" $6}'`;
    percent5=`echo $capacity_sys5 |sed 's/%//g'`

    if [ $percent5 -gt $1  ]
    then
        err2="$size_sys5 $used_sys5 $avail_sys5 capacity: $capacity_sys5 $mounted_sys5"
        err="$err $err2"
        a=1
    fi
done

if [  $a -eq 1  ]
then
    echo $err
    unset err
    exit  $2
fi
}
check_disk 93  "$STATE_CRITICAL"
check_disk 84  "$STATE_WARNING"
echo "disk ok"
exit $STATE_OK
