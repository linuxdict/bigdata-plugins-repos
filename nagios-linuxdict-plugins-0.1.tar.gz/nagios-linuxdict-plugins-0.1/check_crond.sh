#!/bin/bash

pidfile='/var/run/crond.pid'
processPid=`cat ${pidfile}`


if [  ! -z "${processPid}" ]
then
	echo "crond process ok!"
	exit 0
else
	echo "crond process stop!"
	exit 2
fi
