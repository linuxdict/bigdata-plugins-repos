#!/bin/bash

check_model=`/usr/bin/sensors|awk  '/Physical id/ {print $0}'`

if [ ! -z "${check_model}" ]
then
	cpu_temperature=`/usr/bin/sensors|awk  '/Physical id/ && gsub(/+/,"") {print $4}'|awk -F '.' '{print $1}'`
else
	cpu_temperature=`/usr/bin/sensors |awk  '/Core/ && gsub(/+/,"") {print $3}'|awk -F '.' '{print $1}'`
fi

cpu1=0
flag_cpu=0

for i in ${cpu_temperature}
do
	let cpu1++

	if [ $i -gt 85 ]
	then
		cpu_mesg="$cpu_mesg CPU:${cpu1} temperature more than 85 ,now is ${i}."
		flag_cpu=1
	else
		cpu_mesg="$cpu_mesg CPU:${cpu1} temperature ok,now is ${i}"
	fi
done

if [ ${flag_cpu} -eq 1 ]
then
	echo "${cpu_mesg}"
	unset cpu_mesg
	exit 2
else
	echo "${cpu_mesg}"
	unset cpu_mesg
	exit 0
fi
