#!/bin/bash
STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKOWN=3

total=`vmstat 1 6|tail -n 5|awk '{a+=$12}END{printf("%d",a/5)}'`
if [ $total -lt 100000 ]
then
        echo "The system context(cs) is ok!"
        exit $STATE_OK
else
        echo "The system context(cs) exceed 100000 , now is ${totals} !!!"
        exit $STATE_CRITICAL
fi
