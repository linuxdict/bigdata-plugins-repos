#!/bin/bash

tcp_warn_num=10000
task_warn_num=1000
alert_flag=0

ip=`ifconfig em2 |grep 'inet addr'|awk '{print $2}'|awk -F: '{print $2}'`

msg_gea='/data/cron/errs_gearmand'

if netstat -anlop |grep ':4730\>' > /dev/null   
then
	tcpnum=$(netstat -anlop |grep ':4730\>'|wc -l)
	if [ $tcpnum -le ${tcp_warn_num} ];then
        /usr/local/gearmand/bin/gearadmin -h $ip -p 4730 --status | grep -v 'clear_html_cache' > ${msg_gea}
		num_g=`wc -l ${msg_gea}|awk '{print $1}'`
		for (( i=1;i<=${num_g};i++  ))
		do
			ms=`sed -n "${i} p" ${msg_gea}`
			mg=`echo $ms |awk '{print $1}'`
			m=`echo $ms|awk '{print $2}'`
			if [ ! -z $m  ]
			then
				if [ $m -ge ${task_warn_num} ]
				then
					mg2="${mg2}${mg};"
					su_mg=1
				fi
			
			fi
		done	
	else
	    echo "the gearmand tcp connected number more than 10000"
	    exit 2
	fi

else
	echo "gearmand process is stop!"
	exit 2
fi

if [ ! -z ${su_mg}  ]
then
        echo "the gearmand task: $mg2 more than 1000 "
		exit 2
else
		echo "it is all ok"
        exit 0
fi
