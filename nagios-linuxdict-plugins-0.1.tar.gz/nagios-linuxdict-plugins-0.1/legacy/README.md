Legacy Plugins Collection
=========================

This is an older part of the plugins collecion that I think may still be useful. I haven't run some of these in several years, most were written on Python 2.4, so they may need updating to work with newer software dependencies.

I am more inclined to rewrite these in Perl with my current modern utils than to make any significant changes to them beyond bug fixes.

Feature and Bug Requests may prompt in place updates/fixes or complete rewrites to improve code and fit in with my current framework and plugins
