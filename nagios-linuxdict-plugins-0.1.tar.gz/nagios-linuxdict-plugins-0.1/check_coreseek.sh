#!/bin/bash
#ver:1

if netstat -anlop |grep ':9313\>' 
then
	echo "coreseek is ok!"
	exit 0
else
	echo "coreseed porcess is stop!"
	exit 2
fi
