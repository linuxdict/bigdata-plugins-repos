#!/bin/bash

STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKOWN=3

todaytime=`date +%Y-%m-%d`

flag_msg=0
ucenter_task=0

function check_nosqlSlow() {
    if [ -f ${1} ]
    then
        initnosqlSlow=`grep ${2} /tmp/${2} | cut -d: -f2`
        echo '' > /tmp/${2}
        wc -l ${1} |awk '{print "'${2}':"$1}' >> /tmp/${2}
        endnosqlSlow=`wc -l ${1}|awk '{print $1}'`
        let result=${endnosqlSlow:-0}-${initnosqlSlow:-0}
        if [ ${result} -gt 100 ]
        then
            mesg="${mesg} ${2}:${result} more than 100 per 20min;total is ${endnosqlSlow}; "
            flag_msg=1
        else
            mesg="${mesg} ${2}:${result} ok; "
        fi
        if [ ${flag_msg} -eq 1 -o ${ucenter_task} -eq 1 ]
        then
            if [ ${3} -eq 10 ]
            then
                echo "${mesg}"
                exit ${STATE_CRITICAL}
            fi
        else
            if [ ${3} -eq 10 ]
            then
                echo "${mesg}"
                exit ${STATE_OK}
            fi 
        fi
    else
        mesg="${mesg} ${2}:0 OK; "
        if [ ${3} -eq 10 ]
        then
	    if  [ ${ucenter_task} -eq 1 ]
	    then
		echo "${mesg}"
		exit ${STATE_CRITICAL}
	    else
		echo "${mesg}"
		exit ${STATE_OK}
	    fi
        fi
    fi

}

daytime=`date +%F`
if [ -f /tmp/ucenter_task_error_${daytime}.log ]
then
    mesg="${mesg} /tmp/ucenter_task_error_${daytime}.log exist,please check it; "
    ucenter_task=1
fi


check_nosqlSlow "/tmp/redis_slow_${todaytime}.log"              'redis_slow'            1
check_nosqlSlow "/tmp/cache_slow_${todaytime}.log"              'memcache_slow'         2
check_nosqlSlow "/tmp/ucenter_task_slow_${todaytime}.log"       'ucenter_task_slow'     10
unset mesg
