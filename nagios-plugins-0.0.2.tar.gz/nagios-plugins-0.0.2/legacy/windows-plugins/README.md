Windows Plugins
===============

It's been many years since I used these windows plugins so I refer back to the LICENSE, they are provided "AS-IS" with absolutely no warranty! If they work for you, great, if not feel free to modify them to work just make sure to send me the updates for re-inclusion!

A couple of these I used quite a lot, IIRC the check_automatic_services.wsf and check_mcafee_services.wsf back in the days I used to administer McAfee ePO and ProtectionPilot for McAfee Anti-Virus Enterprise.

The third one check_services.wsf I don't think I ever publicly released due to not having spent enough time validating it. It's provided here for reference only. I may finish it if someone sponsors me to do so.

I can't remember if I ever finished the generic services event handler either but have included it here for reference purposes only. I may finish it if someone sponsors me to do so.
