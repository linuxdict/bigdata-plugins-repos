TODO
====

Most of these plugins work with the standard Nagios utils.pm library but I intend to rewrite them to use my personal HariSekhonUtils library before I consider them release-worthy so they are currently here in purgatory.
